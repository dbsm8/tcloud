import Up from './up.svg'
import Down from './down.svg'

export {
  Up,
  Down
}