
export default {
  orange: '#203320',
  red: '#f75353',
  green: '#27AE60',
  blue: '#5264AE',
  lightBlue: '#7082C2',
  grey: '#FFFFFF',
  darkGrey: '#70AE6E',
  black: '#1C1C1C',
  white: '#FFFFFF',
  transparentGrey: 'rgba(95, 95, 95, 0.5)',
  lightGrey: '#BBBBBB'
}
